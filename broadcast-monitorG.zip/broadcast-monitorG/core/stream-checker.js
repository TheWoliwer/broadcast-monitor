const BrowserManager = require('./browser-manager');
const ScreenshotAnalyzer = require('./screenshot-analyzer');
const ColorMatcher = require('./color-matcher');
const logger = require('../utils/logger');
const reportGenerator = require('../utils/report-generator');
const { readJSON, sleep } = require('../utils/helpers');
const TelegramBot = require('../telegram/bot-handler');
const settings = require('../config/settings.json');

class StreamChecker {
  constructor() {
    this.streams = null;
    this.browserManager = null;
    this.intervalId = null;
    this.isRunning = false;
    this.checkCount = 0;
  }

  async initialize() {
    try {
      logger.info('🚀 Broadcast Monitor başlatılıyor...');
      logger.separator();

      this.streams = readJSON('./config/streams.json');
      logger.success(`✅ ${this.streams.machines.length} makina yüklendi`);

      if (settings.telegram.enabled) {
        await TelegramBot.initialize();
      }

      // Browser manager'ı SADECE BİR KEZ başlat
      this.browserManager = new BrowserManager();
      await this.browserManager.init();

      logger.success('✅ Sistem hazır');
      logger.separator();
      
      return true;
    } catch (error) {
      logger.error('❌ Sistem başlatma hatası:', error);
      throw error;
    }
  }

  async checkSingleStream(stream, machineInfo) {
    const result = {
      streamId: stream.streamId,
      streamName: stream.streamName,
      url: stream.url,
      type: stream.type,
      enabled: stream.enabled,
      status: 'UNKNOWN',
      errorType: null,
      message: null,
      timestamp: new Date().toISOString(),
      details: null
    };

    if (!stream.enabled) {
      result.status = 'DISABLED';
      result.message = '⏸️ Yayın devre dışı';
      logger.warning(`⏸️ ${machineInfo.machineName} - Yayın ${stream.streamId}: Devre dışı`);
      return result;
    }

    try {
      logger.info(`\n🔍 Kontrol ediliyor: ${machineInfo.machineName} - ${stream.streamName}`);
      logger.info(`🔗 URL: ${stream.url}`);

      // TARAYICI ZATEN AÇIK - Sadece yeni URL'ye git
      await this.browserManager.navigateToStream(stream.url);

      if (settings.screenshot.saveDebugScreenshots) {
        const filename = `${machineInfo.machineId}-${stream.streamId}-${Date.now()}.png`;
        await this.browserManager.saveDebugScreenshot(filename);
      }

      const screenshot = await this.browserManager.captureScreenshot();

      const pattern = ColorMatcher.getPatternForStreamType(stream.type);
      logger.debug(`📋 Pattern: ${pattern.name}`);

      const viewportSize = this.browserManager.getViewportSize();
      const analyzedPixels = await ScreenshotAnalyzer.analyzePixels(
        screenshot,
        pattern.checkPoints,
        viewportSize
      );

      const matchResult = ColorMatcher.matchesPattern(analyzedPixels);

      result.status = matchResult.verdict;
      result.errorType = matchResult.errorType;
      result.message = matchResult.message;
      result.details = matchResult;

      // TARAYICIYI KAPATMA! Bir sonraki yayın için açık bırak

      return result;

    } catch (error) {
      logger.error(`❌ Yayın kontrol hatası: ${error.message}`);
      
      result.status = 'ERROR';
      result.errorType = 'SYSTEM_ERROR';
      result.message = `⚠️ Sistem hatası: ${error.message}`;

      // Hata durumunda tarayıcıyı yeniden başlat
      try {
        await this.browserManager.restart();
      } catch (restartError) {
        logger.error('Tarayıcı yeniden başlatılamadı:', restartError.message);
      }

      return result;
    }
  }

  async checkMachine(machine) {
    logger.separator();
    logger.info(`🖥️  ${machine.machineName} kontrol ediliyor...`);
    logger.separator();

    const machineResult = {
      machineId: machine.machineId,
      machineName: machine.machineName,
      timestamp: new Date().toISOString(),
      streams: []
    };

    for (const stream of machine.streams) {
      const streamResult = await this.checkSingleStream(stream, machine);
      machineResult.streams.push(streamResult);

      // Her yayın arasında KISA bekleme (tarayıcı zaten açık)
      await sleep(1000); // 2000'den 1000'e düşürdük
    }

    return machineResult;
  }

  async checkAllStreams() {
    try {
      this.checkCount++;
      logger.separator();
      logger.info(`🔄 KONTROL DÖNGÜSÜ #${this.checkCount} BAŞLADI`);
      logger.separator();

      const allResults = [];

      for (const machine of this.streams.machines) {
        const machineResult = await this.checkMachine(machine);
        allResults.push(machineResult);
      }

      const summary = reportGenerator.generateSystemSummary(allResults);
      reportGenerator.printConsoleReport(summary);

      if (settings.telegram.enabled) {
        const errors = reportGenerator.filterErrors(allResults);
        
        if (errors.length > 0 || !settings.telegram.sendOnlyErrors) {
          await TelegramBot.sendStatusReport(summary, errors);
        }
      }

      logger.success(`✅ Kontrol tamamlandı. Sonraki kontrol: ${settings.monitoring.checkInterval / 1000} saniye sonra`);
      
      return allResults;

    } catch (error) {
      logger.error('❌ Kontrol döngüsü hatası:', error);
      
      if (settings.telegram.enabled) {
        await TelegramBot.sendErrorNotification(error);
      }
    }
  }

  async startMonitoring() {
    if (this.isRunning) {
      logger.warning('⚠️ İzleme zaten çalışıyor');
      return;
    }

    this.isRunning = true;
    logger.success('▶️  Otomatik izleme başlatıldı');

    await this.checkAllStreams();

    this.intervalId = setInterval(async () => {
      await this.checkAllStreams();
    }, settings.monitoring.checkInterval);
  }

  stopMonitoring() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
      this.isRunning = false;
      logger.warning('⏸️  İzleme durduruldu');
    }
    
    // Tarayıcıyı temizle
    if (this.browserManager) {
      this.browserManager.cleanup();
    }
  }

  async manualCheck(machineId, streamId) {
    const machine = this.streams.machines.find(m => m.machineId === machineId);
    
    if (!machine) {
      throw new Error(`Makina bulunamadı: ${machineId}`);
    }

    const stream = machine.streams.find(s => s.streamId === streamId);
    
    if (!stream) {
      throw new Error(`Yayın bulunamadı: ${streamId}`);
    }

    return await this.checkSingleStream(stream, machine);
  }
}

module.exports = StreamChecker;
