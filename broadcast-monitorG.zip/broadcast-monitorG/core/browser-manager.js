const puppeteer = require('puppeteer');
const logger = require('../utils/logger');
const { sleep } = require('../utils/helpers');
const settings = require('../config/settings.json');

class BrowserManager {
  constructor() {
    this.browser = null;
    this.page = null;
    this.isInitialized = false;
  }

  async init() {
    if (this.isInitialized && this.browser) {
      logger.debug('♻️  Mevcut tarayıcı kullanılıyor');
      return true;
    }

    try {
      logger.info('🌐 Tarayıcı başlatılıyor...');
      
      this.browser = await puppeteer.launch({
        headless: settings.browser.headless,
        args: settings.browser.args,
        defaultViewport: {
          width: settings.browser.viewportWidth,
          height: settings.browser.viewportHeight
        },
        ignoreHTTPSErrors: true
      });

      this.page = await this.browser.newPage();
      await this.page.setUserAgent(settings.browser.userAgent);
      this.page.setDefaultTimeout(settings.browser.pageLoadTimeout);
      
      // Gereksiz kaynakları engelle (PERFORMANS)
      await this.page.setRequestInterception(true);
      this.page.on('request', (request) => {
        const resourceType = request.resourceType();
        if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
          request.abort();
        } else {
          request.continue();
        }
      });

      this.isInitialized = true;
      logger.success('✅ Tarayıcı başarıyla başlatıldı');
      return true;
    } catch (error) {
      logger.error('❌ Tarayıcı başlatma hatası:', error.message);
      throw error;
    }
  }

  async navigateToStream(url) {
    try {
      logger.info(`📡 Yayına bağlanılıyor: ${url}`);
      
      await this.page.goto(url, {
        waitUntil: 'domcontentloaded',
        timeout: settings.browser.pageLoadTimeout
      });

      await sleep(settings.browser.videoWaitTime);
      
      logger.success('✅ Sayfa yüklendi');
      return true;
    } catch (error) {
      logger.error(`❌ Sayfa yükleme hatası: ${error.message}`);
      throw error;
    }
  }

  async captureScreenshot() {
    try {
      const screenshot = await this.page.screenshot({
        type: 'png',
        encoding: 'binary',
        fullPage: false
      });

      logger.debug(`📸 Screenshot alındı (${screenshot.length} bytes)`);
      return screenshot;
    } catch (error) {
      logger.error('❌ Screenshot alma hatası:', error.message);
      throw error;
    }
  }

  async saveDebugScreenshot(filename) {
    if (!settings.screenshot.saveDebugScreenshots) {
      return;
    }

    try {
      const path = require('path');
      const { ensureDir } = require('../utils/helpers');
      
      ensureDir(settings.screenshot.debugPath);
      
      const filepath = path.join(settings.screenshot.debugPath, filename);
      await this.page.screenshot({ path: filepath, quality: 50 });
      
      logger.debug(`💾 Debug screenshot kaydedildi: ${filepath}`);
    } catch (error) {
      logger.warning('⚠️ Debug screenshot kaydedilemedi:', error.message);
    }
  }

  getViewportSize() {
    return {
      width: settings.browser.viewportWidth,
      height: settings.browser.viewportHeight
    };
  }

  async close() {
    if (settings.performance && settings.performance.reuseSession) {
      logger.debug('♻️  Tarayıcı açık bırakıldı (yeniden kullanılacak)');
      return;
    }

    try {
      if (this.browser) {
        await this.browser.close();
        this.browser = null;
        this.page = null;
        this.isInitialized = false;
        logger.info('🔒 Tarayıcı kapatıldı');
      }
    } catch (error) {
      logger.error('❌ Tarayıcı kapatma hatası:', error.message);
    }
  }

  async cleanup() {
    try {
      if (this.browser) {
        await this.browser.close();
        this.browser = null;
        this.page = null;
        this.isInitialized = false;
        logger.info('✅ Tarayıcı kaynakları temizlendi');
      }
    } catch (error) {
      logger.error('❌ Cleanup hatası:', error.message);
    }
  }

  async restart() {
    try {
      logger.warning('🔄 Tarayıcı yeniden başlatılıyor...');
      
      if (this.browser) {
        await this.browser.close();
      }
      
      this.browser = null;
      this.page = null;
      this.isInitialized = false;
      
      await sleep(2000);
      await this.init();
      
      logger.success('✅ Tarayıcı yeniden başlatıldı');
    } catch (error) {
      logger.error('❌ Tarayıcı yeniden başlatma hatası:', error);
      throw error;
    }
  }
}

module.exports = BrowserManager;
